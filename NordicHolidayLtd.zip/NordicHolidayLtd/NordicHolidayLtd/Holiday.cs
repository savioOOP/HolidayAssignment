﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NordicHolidayLtd
{
    public class Holiday
    {

        private DateTime dateFrom;
        private DateTime dateTo;
        private int stars;
        public int pass;



        public void setdateFrom(DateTime d)
        {
            dateFrom = d;
        }

        public void setdateTo(DateTime t)
        {
            dateTo = t;
        }

        public void setstars(int s)
        {
            stars = s; ;
        }

        public void setpass(int p)
        {
            pass = p; ;
        }

        public DateTime getdateFrom()
        {
            return dateFrom;
        }

        public DateTime getdateTo()
        {
            return dateTo;
        }

        public int getstars()
        {
            return stars;
        }

        public int getpass()
        {
            return pass;
        }

        public bool isPeek(DateTime d)
        {
            bool p = false;
            if (d.Day >= 15 && d.Day <= 15 && d.Month >= 6 && d.Month <= 8)
            {
                p = true;
            }
            return p;
        }

        public double priceOfFlights()
        {
            double price = pass * 238.0;
            if (isPeek(dateFrom) || isPeek(dateTo))
            {
                price = price * 1.2;
            }

            return price;
        }

        public double priceOfAccommodation()
        {
            double ans = 0;
            int numOfNights = dateTo.Subtract(dateFrom).Days;
            if (stars == 3)
            {
                ans += numOfNights * pass * 104.0;
            }
            else if (stars == 4)
            {
                ans += numOfNights * pass * 212.0;
            }
            else if (stars == 5)
            {
                ans += numOfNights * pass * 332.0;
            }

            else if (isPeek(dateFrom) || isPeek(dateTo))
            {
                ans = ans * 1.2;
            }

            return ans;
        }

        public Holiday(DateTime dateFromIn, DateTime dateToIn, int starsIn, int passIn)
        {
            dateFrom = dateFromIn;
            dateTo = dateToIn;
            stars = starsIn;
            pass = passIn;

        }

        public Holiday()
        {
            dateFrom = new DateTime();
            dateTo = new DateTime();
            stars = 0;
            pass = 0;
        }

        public int groups(int n, int size)
        {

            return 5;
        }

        public virtual string printreceipt()
        {
            
            double total = priceOfAccommodation() + priceOfFlights();
            string result = string.Format("{0, -10} {1, 10} \n", "item","value");
            result += string.Format("{0, -10} {1, 10} \n", "flights", priceOfFlights());
            result += string.Format("{0, -10} {1, 10} \n", "accomodation", priceOfAccommodation());
            result += string.Format("{0, -10} {1, 10} \n", "total",total );

            return result;
        }


    }
}