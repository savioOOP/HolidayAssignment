﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NordicHolidayLtd
{

   public class Ski : Holiday
    {
        public Boolean inst;

        public void setinstructor(Boolean b)
        {
            inst = b;
        }

        public Boolean getinstructor()
        {
            return inst;
        }

        public int priceOfInstructor()
        {
            return inst ? groups(pass, 5) * 244 : 0;
        }

        public Ski(DateTime dateFromIn, DateTime dateToIn, int starsIn, int passIn, Boolean instructorIn)
        : base(dateFromIn, dateToIn, starsIn, passIn)
        {

            inst = instructorIn;
        }

        public override string printreceipt()
        {
            double total = priceOfAccommodation() + priceOfFlights();
            string result = string.Format("{0, -10} {1, 10} \n", "item", "VALUE");
            result += string.Format("{0, -10} {1, 10} \n", "flights", priceOfFlights());
            result += string.Format("{0, -10} {1, 10} \n", "accomodation", priceOfAccommodation());
            result += string.Format("{0, -10} {1, 10} \n", "instructor", priceOfInstructor());
            result += string.Format("{0, -10} {1, 10} \n", "total", total);
            return result;
        }

    }
}
