﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NordicHolidayLtd
{
    class Program
    {
        static void Main(string[] args)
        {
            Holiday Hol = null;
            Console.WriteLine("When are you going? ");
            DateTime dateFrom = DateTime.Parse(Console.ReadLine());
            Console.WriteLine("when are you coming back? ");
            DateTime dateTo = DateTime.Parse(Console.ReadLine());
            Console.WriteLine("How many people will you be? ");
            int pass = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter number of stars: ");
            int stars = int.Parse(Console.ReadLine());
            int choice;

            do
            {
                Console.WriteLine("1. Regular");
                Console.WriteLine("2. Ski");
                Console.WriteLine("3. Northern Lights");
                Console.WriteLine("4. Quit");
                choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        Hol = new Holiday(dateFrom, dateTo, stars, pass);
                        break;

                    case 2:
                        Console.WriteLine("Do you want instructor? Y/N: ");
                        bool instructor = true;
                        string group = (Console.ReadLine());
                        if (group.Equals("Y"))
                        {
                            instructor = true;
                        }
                        else
                        {
                            instructor = false;
                        }

                        Hol = new Ski(dateFrom, dateTo, stars, pass, instructor);
                        break;

                    case 3:
                        Console.WriteLine("Do you want Igloo? Y/N: ");
                        bool igloo = true;
                        string group2 = (Console.ReadLine());
                        if (group2.Equals("Y"))
                        {
                            igloo = true;
                        }
                        else
                        {
                            igloo = false;
                        }

                        Console.WriteLine("Was the weather bad? Y/N: ");
                        bool badweather = true;
                        string group3 = (Console.ReadLine());
                        if (group3.Equals("Y"))
                        {
                            badweather = true;
                        }
                        else
                        {
                            badweather = false;
                        }

                        Hol = new NorthernLights(dateFrom, dateTo, stars, pass, igloo, badweather);

                        break;

                    case 4:
                        break;

                    default:
                        Console.WriteLine("Invalid choice!");
                        break;
                }
                Console.WriteLine(Hol.printreceipt());
            } while (choice != 4);

            
            Console.ReadKey();
        }
    }
 }

