﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NordicHolidayLtd
{
    public class NorthernLights : Holiday
    {
        public Boolean igloo;
        public Boolean badweather;
        public double discount;

        public void setigloo(Boolean g)
        {
            igloo = g;
        }

        public void setbadweather(Boolean b)
        {
            badweather = b;
        }

        public Boolean getigloo()
        {
            return igloo;
        }

        public Boolean getbadweather()
        {
            return badweather;
        }

        public int priceOfIgloo()
        {
            return igloo ? groups(pass, 3) * 105 : 0;
        }

        public NorthernLights(DateTime dateFromIn, DateTime dateToIn, int starsIn, int passIn, Boolean iglooIn, Boolean badweatherIn)
        : base(dateFromIn, dateToIn, starsIn, passIn)
        {

            igloo = iglooIn;
            badweather = badweatherIn;
        }

        public override string printreceipt()
        {
            double total = priceOfAccommodation() + priceOfFlights() + priceOfIgloo();
            if (badweather)
            {
                discount = total * 0.2;
                total = total - discount;
            }
            
            string result = string.Format("{0, -10} {1, 10} \n", "item", "VALUE");
            result += string.Format("{0, -10} {1, 10} \n", "flights", priceOfFlights());
            result += string.Format("{0, -10} {1, 10} \n", "accomodation", priceOfAccommodation());
            result += string.Format("{0, -10} {1, 10} \n", "igloo", priceOfIgloo());
            result += string.Format("{0, -10} {1, 10} \n", "discount", discount);
            result += string.Format("{0, -10} {1, 10} \n", "total", total);
            return result;
        }
    }
}

