﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using NordicHolidayLtd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NordicHolidayLtd.Tests
{
    [TestClass()]
    public class SkiTests
    {
        [TestMethod()]
        public void printreceiptTest()
        {
            string str = string.Format("{0, -10} {1, 10} \n", "item", "VALUE");
            str += string.Format("{0, -10} {1, 10} \n", "flights", 1190);
            str += string.Format("{0, -10} {1, 10} \n", "accomodation", 4980);
            str += string.Format("{0, -10} {1, 10} \n", "instructor", 1220);
            str += string.Format("{0, -10} {1, 10} \n", "total", 6170);

            DateTime dep = DateTime.Parse("16 8 2018");
            DateTime ret = DateTime.Parse("19 8 2018");
            Ski S = new Ski(dep, ret, 5, 5, true);
            Assert.AreEqual(str, S.printreceipt());    
        }
    }
}