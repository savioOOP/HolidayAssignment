﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using NordicHolidayLtd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NordicHolidayLtd.Tests
{
    [TestClass()]
    public class NorthernLightsTests
    {
        [TestMethod()]
        public void printreceiptTest()
        {
            string str = string.Format("{0, -10} {1, 10} \n", "item", "VALUE");
            str += string.Format("{0, -10} {1, 10} \n", "flights", );
            str += string.Format("{0, -10} {1, 10} \n", "accomodation", );
            str += string.Format("{0, -10} {1, 10} \n", "igloo", );
            str += string.Format("{0, -10} {1, 10} \n", "discount", );
            str += string.Format("{0, -10} {1, 10} \n", "total", );

            DateTime dep = DateTime.Parse("28 8 2018");
            DateTime ret = DateTime.Parse("1 9 2018");
            Holiday H = new Holiday(dep, ret, 4, 3);
            Assert.AreEqual(str, H.printreceipt());



        }
    }
}