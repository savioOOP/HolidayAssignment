﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using NordicHolidayLtd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NordicHolidayLtd.Tests
{
    [TestClass()]
    public class HolidayTests
    {
        [TestMethod()]
        public void printreceiptTest()
        {

            string str = string.Format("{0, -10} {1, 10} \n", "item", "value");
            str += string.Format("{0, -10} {1, 10} \n", "flights", 714);
            str += string.Format("{0, -10} {1, 10} \n", "accomodation", 1248);
            str += string.Format("{0, -10} {1, 10} \n", "total", 1962);

            DateTime dep = DateTime.Parse("1 5 2018");
            DateTime ret = DateTime.Parse("5 5 2018");
            Holiday H = new Holiday(dep, ret, 3, 3);
            Assert.AreEqual(str, H.printreceipt());       
        }
    }
}